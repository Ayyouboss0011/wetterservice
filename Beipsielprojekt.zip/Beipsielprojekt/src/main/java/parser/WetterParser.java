package parser;
import org.json.JSONArray;
import org.json.JSONObject;
public class WetterParser {
    public void parseData(String jsonData) {
        try {
            JSONObject jsonObject = new JSONObject(jsonData);

            JSONObject hourlyData = jsonObject.getJSONObject("hourly");
            JSONArray timeArray = hourlyData.getJSONArray("time");
            JSONArray temperatureArray = hourlyData.getJSONArray("temperature_2m");

            for (int i = 0; i < timeArray.length(); i++) {
                String time = timeArray.getString(i);
                double temperature = temperatureArray.getDouble(i);

                System.out.println("Zeit: " + time + ", Temperatur: " + temperature + "°C");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
