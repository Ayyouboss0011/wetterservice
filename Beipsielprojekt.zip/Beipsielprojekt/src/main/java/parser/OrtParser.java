package parser;

import API.ApiWetterAbfrage;
import org.json.JSONArray;
import org.json.JSONObject;

public class OrtParser {

    public void parseData(String jSON_Data){
        String jsonResponse = jSON_Data;

        try {
            JSONArray jsonArray = new JSONArray(jsonResponse);
            JSONObject jsonObject = jsonArray.getJSONObject(0); // Assuming only one object in the array

            String lat = jsonObject.getString("lat");
            String lon = jsonObject.getString("lon");

            //printe die Response
            System.out.println("Latitude: " + lat);
            System.out.println("Longitude: " + lon);

            ApiWetterAbfrage a = new ApiWetterAbfrage();
            a.getDataFromAPI(lat, lon);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
