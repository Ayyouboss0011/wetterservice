package main;

import API.ApiOrtAbfrage;

import java.util.Scanner;

public class Wetter {
    public static void main(String[] args) {
        Wetter m = new Wetter();
        m.hauptProgramm();
    }

    public void hauptProgramm(){
        Scanner scanner = new Scanner(System.in);

        System.out.println("Für welche Stadt wollen Sie eine Wetterabfrage durchführen?");
        String Stadt = scanner.nextLine();

        System.out.println("Im welchem Land befindet sich die Stadt?");
        String Land = scanner.nextLine();

        ApiOrtAbfrage o = new ApiOrtAbfrage();
        o.getDataFromAPI(Stadt, Land);

    }
}
