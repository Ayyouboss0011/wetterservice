package API;

import parser.WetterParser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;

public class ApiWetterAbfrage {

    public void getDataFromAPI(String lat, String lon) {
        try {
            URL url = new URL("https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon + "&hourly=temperature_2m");
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("fproxy.lvrintern.lvr.de", 8080));
            HttpURLConnection connection = (HttpURLConnection) url.openConnection(proxy);

            connection.setRequestMethod("GET");

            // Antwort wird gelesen
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            String responseData = response.toString();
            connection.disconnect();

            WetterParser w = new WetterParser();
            w.parseData(responseData);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
