package API;

import parser.OrtParser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;

public class ApiOrtAbfrage {

    public void getDataFromAPI(String Stadt, String Land) {
        try {
            URL url = new URL("https://geocode.maps.co/search?q=" + Stadt + "," + Land + "&api_key=660528feeb35b226420267lvd166c33");
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("fproxy.lvrintern.lvr.de", 8080));
            HttpURLConnection connection = (HttpURLConnection) url.openConnection(proxy);

            connection.setRequestMethod("GET");

            // Antwort wird gelesen
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            String responseData = response.toString();
            connection.disconnect();

            // Instanziieren Sie die Parser-Klasse und rufen Sie die parseData-Methode auf
            OrtParser p = new OrtParser();
            p.parseData(responseData);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
